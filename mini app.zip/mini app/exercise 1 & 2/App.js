import React from 'react';
import './App.css';

class App  extends  React.Component {
  state={
    name:"name state"
  }
  render() {
  return (
 <React.Fragment>      
   <div className="comment">

    <img width="60px" height="60px" src="https://cdn.business2community.com/wp-content/uploads/2017/08/blank-profile-picture-973460_640.png"/>

    <div className="name">Asem Qaffaf  
   <div className="text"> i have something to do</div> 
   <button className="button">Like</button>
   <button className="button">Commment</button>
   </div>
    </div>
    <div className="main">
    <div className="menu">
    <div className="card">
      <div className="card-color">
        <center>
      <div className="card-name">  John Whayn</div>
        </center>
        </div>
        <center>
          <div className="card-info">email@gmail.com</div>
          <div className="card-info">+1 837373 76637</div>
  <button  className="button-card card-info" > Click on me</button>
  </center>
  </div>
  <div className="card">
      <div className="card-color">
        <center>
      <div className="card-name">  John Whayn</div>
        </center>
        </div>
        <center>
          <div className="card-info">email@gmail.com</div>
          <div className="card-info">+1 837373 76637</div>
  <button  className="button-card card-info" > Click on me</button>
  </center>
  </div>
  <div className="card">
      <div className="card-color">
        <center>
      <div className="card-name">  John Whayn</div>
        </center>
        </div>
        <center>
          <div className="card-info">email@gmail.com</div>
          <div className="card-info">+1 837373 76637</div>
  <button  className="button-card card-info" > Click on me</button>
  </center>
  </div>
  </div>
  <div >
    
    
    <div className="card-left">
      <div className="card-color">
        <center>
      <div className="card-name"> {this.state.name}</div>
        </center>
        </div>
        <center>
          <div className="card-info">email@gmail.com</div>
          <div className="card-info">+1 837373 76637</div>
  {/* <button  className="button-card card-info" > Click on me</button> */}
  </center>
  </div>

  </div>
  </div>
  </React.Fragment>

  );
}
}
export default App;

